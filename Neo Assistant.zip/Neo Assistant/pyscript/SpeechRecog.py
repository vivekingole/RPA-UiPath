import winsound
import os
import speech_recognition as sr
# python -m pip install plyer
from plyer import notification

r=sr.Recognizer()

def Speech(notify):
        output=""
        while(len(output)==0 or output == None):
                notification.notify(message="Listening",timeout=5)
                #winsound.Beep(2500,30)
                with sr.Microphone() as source:
                    audio=r.listen(source)
                try:
                    output = r.recognize_google(audio)
                except:
                    pass
        if(notify):
                notification.notify(message=output,timeout=5)
        return output

def Notify(message1):
        notification.notify(message=message1,timeout=5)

