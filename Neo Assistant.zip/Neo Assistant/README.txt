This plug and play project recognises human's voice using google's AI algorithms and convert into readable text. This UiPath's workflow is invoking a python script which requires python to be installed. This code is capable enough to recognise any type of acsent and language.
Python's recommended version - 3.6

Applications
UiPath 19.8
Python

Get the below python libraries
[1] pip install SpeechRecognition
[2] pip install PyAudio